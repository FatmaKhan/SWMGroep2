﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Internship.Data.DomainClasses;
using Internship.Desktop.Data;
using NUnit.Framework;

namespace Internship.Desktop.Tests
{
    [TestFixture]
    class ParseServiceTests
    {
        [Test]
        public void ParseOudStagevoorstel_ReturnsListOfOudStagevoorstel()
        {
            //Arrange
            string line = CsvStringBuilder.ParseToCsv(new StagevoorstelBuilder().Build());

            //Act
            var resultData = ParseService.ParseOudStageVoorstel(line.Split(ParseService.DELIMITER)) as OudStagevoorstel;

            //Assert
            Assert.That(resultData, Is.Not.Null);
            Assert.That(resultData.AantalGewensteStagiars, Is.Not.Null);
            Assert.That(resultData.EmailContactpersoon, Is.Not.Null);
            Assert.That(resultData.Bemerkingen, Is.Not.Null);
        }

        [Test]
        public void ParseOudeStage_ReturnsListOfOudeStage()
        {
            //Arrange
            string line = CsvStringBuilder.ParseToCsv(new StageBuilder().Build());

            //Act
            var resultData = ParseService.ParseOudeStage(line.Split(ParseService.DELIMITER)) as OudeStage;

            //Assert
            Assert.That(resultData, Is.Not.Null);
            Assert.That(resultData.EmailPromotor, Is.Not.Null);
            Assert.That(resultData.VoornaamContactpersoon, Is.Not.Null);
            Assert.That(resultData.Bemerkingen, Is.Not.Null);
        }

        class StagevoorstelBuilder
        {
            private OudStagevoorstel voorstel;
            private Random random;

            public StagevoorstelBuilder()
            {
                random = new Random();
                voorstel = new OudStagevoorstel();
                foreach (var p in voorstel.GetType().GetProperties().Where(p => p.GetGetMethod().GetParameters().Count() == 0))
                {
                    p.SetValue(voorstel, Guid.NewGuid().ToString());
                }
            }

            public OudStagevoorstel Build()
            {
                return voorstel;
            }
        }

        class StageBuilder
        {
            private OudeStage stage;
            private Random random;

            public StageBuilder()
            {
                stage = new OudeStage();
                random = new Random();
                foreach (var p in stage.GetType().GetProperties().Where(p => p.GetGetMethod().GetParameters().Count() == 0))
                {
                    p.SetValue(stage, Guid.NewGuid().ToString());
                }
            }

            public OudeStage Build()
            {
                return stage;
            }
        }

        class CsvStringBuilder
        {
            public static string ParseToCsv(object obj)
            {
                StringBuilder stringBuilder = new StringBuilder();
                foreach (var p in obj.GetType().GetProperties().Where(p => p.GetGetMethod().GetParameters().Count() == 0))
                {
                    stringBuilder.Append(p.GetValue(obj, null) + "\t");
                }
                return stringBuilder.ToString();
            }
        }
    }
}
