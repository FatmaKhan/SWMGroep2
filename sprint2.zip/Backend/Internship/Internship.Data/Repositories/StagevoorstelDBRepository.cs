﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Internship.Data.DomainClasses;
using System.Data.Entity;

namespace Internship.Data.Repositories
{
    public class StagevoorstelDBRepository : IStagevoorstelRepository
    {
        private ApplicationDbContext _context;

        public StagevoorstelDBRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public IEnumerable<Stagevoorstel> GetAll()
        {
            return _context.Stagevoorstellen.ToList();
        }

        public Stagevoorstel Post(Stagevoorstel stagevoorstel)
        {
            _context.Bedrijfspromotors.Add(stagevoorstel.Stageopdracht.Bedrijfspromotor);
            _context.Contactpersonen.Add(stagevoorstel.Stageopdracht.Contactpersoon);
            
            _context.Stagevoorstellen.Add(stagevoorstel);
            _context.SaveChanges();
            return stagevoorstel;
        }

        public Stagevoorstel Get(int id)
        {
            return _context.Stagevoorstellen.FirstOrDefault(s => s.Id == id);
        }

        public Stagevoorstel GetByTimeStamp(DateTime timeStamp)
        {
            return _context.Stagevoorstellen.FirstOrDefault(s => s.TimeStamp.Equals(timeStamp));
        }

        public void Update(Stagevoorstel stagevoorstel)
        {
            var contextStagevoorstel = _context.Stagevoorstellen.FirstOrDefault(s => s.Id == stagevoorstel.Id);
            contextStagevoorstel.Review = stagevoorstel.Review;
            contextStagevoorstel.Stageopdracht.Status = stagevoorstel.Stageopdracht.Status;
            _context.SaveChanges();
        }

        public void Delete(int id)
        {
            Stagevoorstel stagevoorstel = _context.Stagevoorstellen.FirstOrDefault(s => s.Id == id);
            _context.Stagevoorstellen.Remove(stagevoorstel);
            _context.SaveChanges();
        }

        public Stagevoorstel GetDetail(int id)
        {
            return _context.Stagevoorstellen.Include(s => s.Review).Include(s => s.Stageopdracht).Include(s => s.Stageopdracht.Bedrijfspromotor).Include(s => s.Stageopdracht.Contactpersoon).FirstOrDefault(s => s.Id == id);
        }
    }
}
