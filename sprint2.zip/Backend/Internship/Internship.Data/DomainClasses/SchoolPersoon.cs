﻿namespace Internship.Data.DomainClasses
{
    public class SchoolPersoon : Persoon
    {
        public string Nummer { get; set; }
        public string SchoolMail { get; set; }
        public string Password { get; set; }
        public string ConfirmPassword { get; set; }
        public bool IsGeregistreerd { get; set; }
    }
}