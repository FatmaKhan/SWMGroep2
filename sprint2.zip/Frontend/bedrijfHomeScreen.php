<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Home</title>

    <meta name="description" content="Homescreen bedrijf">
    <meta name="author" content="AON13">


    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/styleHome.css" rel="stylesheet">
    <link href="assets/css/datatables.min.css" rel="stylesheet">

    <!-- Favicon and touch icons -->
    <link rel="shortcut icon" href="assets/ico/favicon.png">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">

</head>
<body>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-6">
                    <div class="row">
                        <div class="col-md-5">
                        </div>
                        <div class="col-md-7">
                            <h1>
                                <b id="welkom">Welkom </b>
                            </h1>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="row">
                        <div class="col-md-9">
                        </div>
                        <div class="col-md-3">
                            <a id="afmelden" href="verwerkAfmelden.php" class="btn btn-link">Afmelden<img
                                        id="afmeldenPng"
                                        alt="afmelden"
                                        src="assets/img/afmelden.png"/></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <img id="logoPxl" alt="Logo pxl" src="assets/img/pxllogowitterand.png">
                    <a href="bedrijfHomeScreen.php" class="btn btn-block">Home</a>
                </div>
                <div class="col-md-6">
                    <a href="indienenStageopdracht.php" class="btn btn-block">Stageopdracht indienen</a>
                </div>
            </div>
        </div>
    </div>
    <div class="row">

    </div>
    <div class="col-md-12">
        <h3>
            Uw ingediende stageopdrachten
        </h3>
        <table id="table1" class="table table-bordered">
            <thead>
            <tr>
                <th>
                    Functie
                </th>
                <th>
                    Status
                </th>
                <th>
                    Aantal keren als favoriet
                </th>
            </tr>
            </thead>
            <tbody>

            </tbody>
        </table>
        <br>
        <button type="button" class="btn btn-indienen" onclick="location.href='indienenStageopdracht.php'">
            Stageopdracht indienen
        </button>
    </div>
</div>
</div>

<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/scriptHome.js"></script>
<script src="assets/js/datatables.min.js"></script>
<script src="assets/js/afmelden.js"></script>
<script src="assets/js/initializeDatatables.js"></script>
<script src="assets/js/dataTransfer.js"></script>
<script src="assets/js/sessionTimeout.js"></script>

<script>
    $(document).ready(function () {
        var contents = document.getElementById('welkom').innerHTML;
        contents += sessionStorage.getItem('username');
        document.getElementById('welkom').innerHTML = contents;
        $.ajax({
            url: "http://localhost:57280/api/bedrijf/home/" + sessionStorage.getItem("userId"),
            type: "Get",
            dataType: "json",
            async: false,
            success: function (data) {
                // Success callback
                for (var j = 0; j < data.IngediendeStagevoorstellen.length; j++) {
                    var functie = data.IngediendeStagevoorstellen[j].Stageopdracht.Omgeving;
                    var status = data.IngediendeStagevoorstellen[j].Stageopdracht.Status;
                    var aantalFavoriet = data.IngediendeStagevoorstellen[j].Stageopdracht.StudentFavorieten.length;
                    if (status == 0 || status == 1) {
                        status = "In behandeling";
                        $('#table1 tbody').append('<tr class="warning"><td>' + functie + '</td><td>' + status + '</td><td><img class="hartje" src="assets/img/hartje.png" alt="hartje">' + aantalFavoriet + '</td></tr>')
                    } else if (status == 2) {
                        status = "Goedgekeurd";
                        $('#table1 tbody').append('<tr class="success"><td>' + functie + '</td><td>' + status + '</td><td><img class="hartje" src="assets/img/hartje.png" alt="hartje">' + aantalFavoriet + '</td></tr>')
                    } else if (status == 3) {
                        status = "Afgekeurd"
                        $('#table1 tbody').append('<tr class="danger"><td>' + functie + '</td><td>' + status + '</td><td><img class="hartje" src="assets/img/hartje.png" alt="hartje">' + aantalFavoriet + '</td></tr>')
                    }
                }
            },
            error: function (msg) {
                alert("Error!" + msg.toString());
            }
        });
        $('#table1').DataTable();
    });
</script>
</body>
</html>