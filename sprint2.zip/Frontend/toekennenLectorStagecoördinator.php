<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Lector toekennen</title>

    <meta name="description" content="Review Stageopdracht">
    <meta name="author" content="AON13">

    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/styleHome.css" rel="stylesheet">

    <!-- Favicon and touch icons -->
    <link rel="shortcut icon" href="assets/ico/favicon.png">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">

</head>
<body>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-6">
                    <div class="row">
                        <div class="col-md-5">
                        </div>
                        <div class="col-md-7">

                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="row">
                        <div class="col-md-9">
                        </div>
                        <div class="col-md-3">
                            <a id="afmelden" href="verwerkAfmelden.php" class="btn btn-link">Afmelden<img id="afmeldenPng"
                                                                                            alt="afmelden"
                                                                                            src="assets/img/afmelden.png"/></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <img id="logoPxl" alt="Logo pxl" src="assets/img/pxllogowitterand.png">
                    <a href="lectorHomeScreen.php" class="btn btn-block home-btn">Home</a>
                </div>
            </div>
        </div>
    </div>
    <div class="row opdrachtForm">
        <div class="col-md-12">
            <h3>
                Data Unit
            </h3>

            <form role="form" action="" method="post" class="login-form">
                <textarea readonly id="opdracht">Bedrijf / opdrachtgever :​ ​Data Unit

Adres: LINDEKENSVELD 5 bus 1.1
           3560 LUMMEN

Contactpersoon: dhr Johan Holsteyns
                           11279207
                           Johan.holsteyns@dataunit.be

Bedrijfspromotor: dhrPieter Rubens
                             11279207
                             Pieter.rubens@dataunit.be

Aantal medewerkers: 50

Aantal IT medewerkers: 25 ​

Aantal technische begeleiders: 3​

Afstudeerrichting:​ Systemen en Netwerkbeheer

Opdracht

Reeds geruime tijd is de Europese Unie bezig met het uitschrijven van een wetgeving in
verband met data protectie. De General Data Protection Regulation (GDPR) zal een
grote invloed hebben op alle bedrijven die persoonsgegevens verzamelen en
verwerken. Grote financiële penaliteiten verplichten hen om conform de regulatie te
werken.

De stagiair zal een studie maken over GDPR . In een overzicht geeft hij aan, aan welke
eisen elk bedrijf moet voldoen en hoe dit praktisch wordt ingericht.
Nadien zal hij zijn bevindingen toepassen op Data Unit. Daarbij maakt hij gebruik van
het productgamma van Data Unit. De stagiair geeft aan:
-   Welke oplossingen kunnen gebruikt worden bij de implementatie van GDPR
-   Welke oplossingen Data Unit ontbreekt in zijn productgamma voor de uitrol van
GDPR
-   Testen van één of meerdere applicaties.
-   Aangeven hoe Data Unit een ondersteunende rol kan spelen in de uitrol van
GDPR bij bestaande klanten.

Extra Info

Data Unit is een bedrijf gespecialiseerd in het leveren, configureren en onderhouden
van netwerk, voice en security appartatuur.

Omgeving

Systemen&Netwerken: Linux, Windows, ..., security

Randvoorwaarden

Er kunnen verplaatsingen zijn naar Bxl. De hoofdstage locatie is in Lummen

Onderzoeksthema

GDPR

Inleidende Activiteiten:

Aantal studenten:​ 1 student

Aanwezig op het Handshake Event: Neen</textarea>
                <br>
                <br>
                <label for="reviewer">Reviewer</label>
                <br>
                <select id="reviewer">
                    <option selected value="Bram Heyns">Bram Heyns</option>
                    <option value="Marijke Willems">Marijke Willems</option>
                    <option value="David Parren">David Parren</option>
                    <option value="Luc Doumen">Luc Doumen</option>
                    <option value="Nathalie Fuchs">Nathalie Fuchs</option>
                    <option value="Jan Willekens">Jan Willekens</option>
                    <option value="Kris Hermans">Kris Hermans</option>
                    <option value="Tim Dupont">Tim Dupont</option>
                    <option value="Gert Vanwaeyenberg">Gert Vanwaeyenberg</option>
                    <option value="Bart Moelans">Bart Moelans</option>
                    <option value="Peter Vaes">Peter Vaes</option>
                </select>
                <br>
                <br>
                <br>
                <button type="submit" name="handmatig" class="btn-indienen btn"><img src="assets/img/ToekennenLector.png"> Handmatig toekennen</button>
                <button type="submit" name="automatisch" class="btn-indienen btn"><img src="assets/img/ToekennenLector.png"> Automatisch toekennen</button>
                <br>
                <br>
                <br>
                <br>
            </form>
        </div>
    </div>
</div>

<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/scriptHome.js"></script>
<script src="assets/js/afmelden.js"></script>


</body>
</html>