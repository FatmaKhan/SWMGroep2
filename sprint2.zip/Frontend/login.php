<!DOCTYPE html>
<html lang="en" xmlns:http="http://www.w3.org/1999/xhtml">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Inloggen</title>

    <!-- CSS -->
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/form-elements.css">
    <link rel="stylesheet" href="assets/css/style.css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

    <!-- Favicon and touch icons -->
    <link rel="shortcut icon" href="assets/ico/favicon.png">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">

</head>

<body>
<!-- Top content -->
<div class="top-content">
    <div class="inner-bg">
        <div class="container">
            <div class="row">
                <div class="col-sm-8 col-sm-offset-2 text">
                </div>
            </div>
            <div class="row">
                <div class="col-sm-6 col-sm-offset-3 form-box">
                    <div class="form-top">
                        <div class="form-top-left strokeme">
                            <h3>Inloggen</h3>
                            <p>Geef uw gebruikernaam en wachtwoord in om aan te melden:</p>
                        </div>
                        <div class="form-top-right">
                            <i class="fa fa-lock"></i>
                        </div>
                    </div>
                    <div class="form-bottom">
                        <div class="form-group">
                            <label class="sr-only" for="form-username">Gebruikersnaam</label>
                            <input type="text" name="form-username" placeholder="Gebruikernaam..."
                                   class="form-username form-control" id="form-username">
                        </div>
                        <div class="form-group">
                            <label class="sr-only" for="password">Wachtwoord</label>
                            <input type="password" name="form-password" placeholder="Wachtwoord..."
                                   class="form-password form-control" id="form-password">
                        </div>
                        <div class="login-form">
                            <button type="button" class="btn"
                                    onclick="authenticate(document.getElementById('form-username').value, document.getElementById('form-password').value)">
                                Aanmelden
                            </button>
                        </div>
                        <form role="form" action="#" method="post" class="login-form" id="login-form">
                            <input type="hidden" id="username" name="username" value="#">
                            <input type="hidden" id="token" name="token" value="#">
                        </form>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-6 col-sm-offset-3 social-login">
                    <div class="registreerbuttons">
                        <a class="btn btn-link-2" href="registreren.php">
                            Registreren
                        </a>
                        <a class="btn btn-link-2" href="registrerenBedrijf.php">
                            Registreren voor bedrijven
                        </a>
                        <a class="btn btn-link-2" href="wachtwoordVergeten.php">
                            Wachtwoord vergeten?
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>


<!-- Javascript -->
<script src="assets/js/jquery-1.11.1.min.js"></script>
<script src="assets/bootstrap/js/bootstrap.min.js"></script>
<script src="assets/js/jquery.backstretch.min.js"></script>
<script src="assets/js/scripts.js"></script>
<script src="assets/js/dataTransfer.js"></script>
<script type="text/javascript">
    function authenticate($username, $password) {
        $(document).ready(function () {
            $.ajax({
                url: 'http://localhost:57280/Token',
                type: 'Post',
                contentType: 'application/x-www-form-urlencoded',
                dataType: 'json',
                data: encodeURI('userName=' + $username + '&password=' + $password + '&grant_type=password&Submit=Login'),
                success: function (data) {
                    var $bearerToken = data.access_token;
                    var $username = data.userName;
                    var userId = data.userId;
                    var user = null;
                    $username = $username.substring(0, $username.indexOf('@'));
                    setHiddenField('username', $username);
                    setHiddenField('token', $bearerToken);
                    sessionStorage.setItem('tokenKey', $bearerToken);

                    $.ajax({
                        url: "http://localhost:57280/api/Account/" + userId,
                        type: "Get",
                        dataType: "json",
                        async: false,
                        success: function (data) {
                            user = data;
                        },
                        error: function (msg) {
                            alert("Error!" + msg.toString());
                        }
                    });

                    if (data.isStudent) {
                        sessionStorage.setItem('role', 'student');
                        sessionStorage.setItem('userId', user.StudentInfo.Id);
                        sessionStorage.setItem('username', user.StudentInfo.Voornaam + " " + user.StudentInfo.Achternaam);
                        setFormAction('login-form', "studentHomeScreen.php");
                        submitForm('login-form');
                    }
                    if (data.isTeacher) {
                        sessionStorage.setItem('role', 'lector');
                        sessionStorage.setItem('userId', user.LectorInfo.Id);
                        sessionStorage.setItem('username', user.LectorInfo.Voornaam + " " + user.LectorInfo.Achternaam);
                        setFormAction('login-form', "lectorHomeScreen.php");
                        submitForm('login-form');
                    }
                    if (data.isCompany) {
                        sessionStorage.setItem('role', 'bedrijf');
                        sessionStorage.setItem('userId', user.BedrijfInfo.Id);
                        sessionStorage.setItem('username', user.BedrijfInfo.Bedrijfsnaam);
                        setFormAction('login-form', "bedrijfHomeScreen.php");
                        submitForm('login-form');
                    }
                    if (data.isCoordinator) {
                        sessionStorage.setItem('role', 'coordinator');
                        sessionStorage.setItem('userId', user.StagecoördinatorInfo.Id);
                        sessionStorage.setItem('username', user.StagecoördinatorInfo.Voornaam + " " + user.StagecoördinatorInfo.Achternaam);
                        setFormAction('login-form', "stagecoordinatorHomeScreen.php");
                        submitForm('login-form');
                    }
                },
                error: function (data, jqXHR, textStatus, errorThrown) {
                    alert("Error: Status: " + textStatus + " Message: " + errorThrown + data);
                }
            });
        });
    }
</script>

<!--[if lt IE 10]>
<script src="assets/js/placeholder.js"></script>
<![endif]-->

</body>

</html>