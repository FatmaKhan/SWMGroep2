<?php

header("Location: bedrijfHomeScreen.php"); /* Redirect browser */
exit();