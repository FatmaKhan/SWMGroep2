/**
 * Created by Spape on 8/05/2017.
 */
setTimeout(function () {
    sessionStorage.removeItem('tokenKey');
    window.location.href = "verwerkAfmelden.php";
}, 30 * 60000);
