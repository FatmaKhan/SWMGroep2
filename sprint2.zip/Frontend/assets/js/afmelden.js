/**
 * Created by Maarten on 04/22/2017.
 */
$(document).ready(function() {
    $('#afmelden').click(function (event) {
        event.preventDefault();
        sessionStorage.removeItem('tokenKey');
        window.open ('verwerkAfmelden.php','_self');
    });
});