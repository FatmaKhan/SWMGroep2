<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Detail Stageopdracht</title>

    <meta name="description" content="Review Stageopdracht">
    <meta name="author" content="AON13">

    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/styleHome.css" rel="stylesheet">

    <!-- Favicon and touch icons -->
    <link rel="shortcut icon" href="assets/ico/favicon.png">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">

</head>
<body>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-6">
                    <div class="row">
                        <div class="col-md-5">
                        </div>
                        <div class="col-md-7">

                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="row">
                        <div class="col-md-9">
                        </div>
                        <div class="col-md-3">
                            <a id="afmelden" href="verwerkAfmelden.php" class="btn btn-link">Afmelden<img
                                        id="afmeldenPng"
                                        alt="afmelden"
                                        src="assets/img/afmelden.png"/></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <img id="logoPxl" alt="Logo pxl" src="assets/img/pxllogowitterand.png">
                    <a href="studentHomeScreen.php" class="btn btn-block home-btn">Home</a>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="row">
                    <div class="col-md-3">
                        <h3>
                            Adresgegevens
                        </h3>
                        <address>
                            <strong id="bedrijfsnaam"></strong><br/><span id="adres"></span><br/><span
                                    id="gemeente"></span><br/><abbr title="Phone">P:</abbr><span
                                    id="telefoonnummer"></span>
                        </address>
                    </div>
                    <div class="col-md-9">
                        <h3>
                            Technische informatie
                        </h3>
                        <strong>Aantal gewenste stagiairs: </strong>
                        <span id="aantalGewensteStagiairs"></span><br/>
                        <strong>Omgeving: </strong>
                        <span id="omgeving"></span><br/>
                        <strong>Afstudeerrichting: </strong>
                        <span id="afstudeerrichting"></span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <h3>
                            Stageopdracht
                        </h3>
                        <strong>Omschrijving</strong><br/>
                        <p id="omschrijving"></p>
                        <strong>Verwachtingen</strong><br/>
                        <p id="verwachtingen"></p>
                        <strong>Randvoorwaarden</strong><br/>
                        <p id="randvoorwaarden"></p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <br/>
                        <br/>
                        <form role="form" action="" method="post" class="login-form">
                            <button type="submit" name="exporterenNaarPDF" class="btn-indienen btn"><img
                                        src="assets/img/ExporterenPDF.png"> Exporteren naar PDF
                            </button>
                            <button type="submit" name="selecteerStagevoorstel" class="btn-indienen btn"><img
                                        src="assets/img/Selecteren.png"> Selecteer stagevoorstel
                            </button>
                        </form>
                        <br>
                        <button type="submit" name="markeerAlsFavoriet" class="btn-indienen btn"
                                id="markeerAlsFavoriet">Vind ik leuk
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/scriptHome.js"></script>
<script src="assets/js/afmelden.js"></script>
<script src="assets/js/sessionTimeout.js"></script>

<script>
    $(document).ready(function () {
        var status = false;
        var stageopdracht;
        $('#markeerAlsFavoriet').click(function () {
            $.ajax({
                url: "http://localhost:57280/api/stageopdrachten/updateFavorite/" + <?php echo $_POST['id_opdracht']; ?> +"/1",
                type: "PUT",
                data: stageopdracht,
                async: false,
                success: function (data) {
                    if (status) {
                        $('#markeerAlsFavoriet').html("Vind ik leuk");
                        status = false;
                    } else {
                        $('#markeerAlsFavoriet').html("Vind ik niet meer leuk");
                        status = true;
                    }
                },
                error: function (data, jqXHR, textStatus, errorThrown) {
                    alert("Error: Status: " + textStatus + " Message: " + errorThrown + data);
                }
            });
        });

        $.ajax({
            url: "http://localhost:57280/api/stageopdrachten/favorites/" + <?php echo $_POST['id_opdracht']; ?>,
            type: "Get",
            dataType: "json",
            async: false,
            success: function (data) {
                stageopdracht = data;
                //Bedrijf
                $('#bedrijfsnaam').html(data.Opdrachtgever.Bedrijfsnaam);
                $('#adres').html(data.Opdrachtgever.Adres + " " + data.Opdrachtgever.Huisnummer);
                $('#gemeente').html(data.Opdrachtgever.Postcode + " " + data.Opdrachtgever.Gemeente);
                $('#telefoonnummer').html(data.Opdrachtgever.Telefoonnummer);

                //Technische informatie
                $('#aantalGewensteStagiairs').html(data.AantalGewensteStagiairs);
                $('#omgeving').html(data.Omgeving);
                $('#afstudeerrichting').html(getAfstudeerRichting(data.VoorkeurAfstudeerrichting));

                //Stageopdracht
                $('#omschrijving').html(data.Omschrijving);
                $('#verwachtingen').html(data.Verwachtingen);
                $('#randvoorwaarden').html(data.Randvoorwaarden);

                for (var i = 0; i < data.StudentFavorieten.length; i++) {
                    if (data.StudentFavorieten[i].Id == 1) {
                        $('#markeerAlsFavoriet').html('Vind ik niet meer leuk');
                        status = true;
                        break;
                    }
                }
            },
            error: function (data, jqXHR, textStatus, errorThrown) {
                alert("Error: Status: " + textStatus + " Message: " + errorThrown + data);
            }
        });

        function getAfstudeerRichting(afstudeerrichting) {
            if (afstudeerrichting == 0) {
                afstudeerrichting = "Applicatie ontwikkeling"
            } else if (afstudeerrichting == 1) {
                afstudeerrichting = "Systeem en netwerkbeheer"
            } else if (afstudeerrichting == 2) {
                afstudeerrichting = "Softwaremanagement"
            }
            return afstudeerrichting;
        }
    });
</script>
</body>
</html>