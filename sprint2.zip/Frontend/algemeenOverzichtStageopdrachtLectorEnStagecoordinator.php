<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Overzicht stageopdracht</title>

    <meta name="description" content="Review Stageopdracht">
    <meta name="author" content="AON13">

    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/styleHome.css" rel="stylesheet">

    <!-- Favicon and touch icons -->
    <link rel="shortcut icon" href="assets/ico/favicon.png">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">

</head>
<body>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-6">
                    <div class="row">
                        <div class="col-md-5">
                        </div>
                        <div class="col-md-7">

                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="row">
                        <div class="col-md-9">
                        </div>
                        <div class="col-md-3">
                            <a id="afmelden" href="verwerkAfmelden.php" class="btn btn-link">Afmelden<img
                                        id="afmeldenPng"
                                        alt="afmelden"
                                        src="assets/img/afmelden.png"/></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <img id="logoPxl" alt="Logo pxl" src="assets/img/pxllogowitterand.png">
                    <a href="lectorHomeScreen.php" class="btn btn-block home-btn" id="href">Home</a>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-4">
                <h3>
                    Adresgegevens
                </h3>
                <address>
                    <strong id="bedrijfsnaam"></strong><br/><span id="adres"></span><br/><span
                            id="gemeente"></span><br/><abbr title="Phone">P:</abbr><span
                            id="telefoonnummer"></span>
                </address>
            </div>
            <div class="col-md-4">
                <h3>
                    Contactpersoon
                </h3>
                <strong>Naam: </strong>
                <span id="naamContactpersoon"></span><br/>
                <strong>Email: </strong>
                <span id="emailContactpersoon"></span><br/>
                <abbr title="Phone">P:</abbr>
                <span id="telefoonnummerContactpersoon"></span>
            </div>
            <div class="col-md-4">
                <h3>
                    Bedrijfspromotor
                </h3>
                <strong>Naam: </strong>
                <span id="naamBedrijfspromotor"></span><br/>
                <strong>Email: </strong>
                <span id="emailBedrijfspromotor"></span><br/>
                <abbr title="Phone">P:</abbr>
                <span id="telefoonnummerBedrijfspromotor"></span>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <h3>
                    Technische informatie
                </h3>
                <strong>Aantal gewenste stagiairs: </strong>
                <span id="aantalGewensteStagiairs"></span><br/>
                <strong>Omgeving: </strong>
                <span id="omgeving"></span><br/>
                <strong>Afstudeerrichting: </strong>
                <span id="afstudeerrichting"></span>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <h3>
                    Stageopdracht
                </h3>
                <strong>Omschrijving</strong><br/>
                <p id="omschrijving"></p>
                <strong>Verwachtingen</strong><br/>
                <p id="verwachtingen"></p>
                <strong>Randvoorwaarden</strong><br/>
                <p id="randvoorwaarden"></p>
            </div>
        </div>
        <br>
        <div class="row">
            <div class="col-md-12">
                <h3>
                    Review
                </h3>
                <div class="form-group" id="form">
                    <label for="feedback">Feedback</label>
                    <textarea id="feedback" name="feedback" class="form-control" rows="5"></textarea><br>
                    <button type="submit" name="goedkeuren" id="goedkeurenButton" class="btn-indienen btn"><img
                                src="assets/img/Goedkeuren.png"> Goedkeuren
                    </button>
                    <button type="submit" name="afkeuren" id="afkeurenButton" class="btn-indienen btn"><img src="assets/img/Afkeuren.png">
                        Afkeuren
                    </button>
                </div>
                <div class="form-group" id="review">
                    <textarea id="reviewFeedback" name="feedback" class="form-control" rows="5" disabled></textarea>
                    <p id="status"></p>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/scriptHome.js"></script>
<script src="assets/js/initializeDatatables.js"></script>
<script src="assets/js/dataTransfer.js"></script>
<script src="assets/js/sessionTimeout.js"></script>

<script>
    var stagevoorstel;
    $(document).ready(function () {
        if(sessionStorage.getItem('role') == "coordinator"){
            $('#href').attr("href", "stagecoordinatorHomeScreen.php")
        }

        function getAfstudeerRichting(afstudeerrichting) {
            if (afstudeerrichting == 0) {
                afstudeerrichting = "Applicatie ontwikkeling"
            } else if (afstudeerrichting == 1) {
                afstudeerrichting = "Systeem en netwerkbeheer"
            } else if (afstudeerrichting == 2) {
                afstudeerrichting = "Softwaremanagement"
            }
            return afstudeerrichting;
        }

        function checkReview() {
            if(stagevoorstel.Review == null){
                $('#form').show();
                $('#review').hide();
            }else{
                $('#review').show();
                $('#form').hide();
                $('#reviewFeedback').html(stagevoorstel.Review.Feedback);
                if(stagevoorstel.Stageopdracht.Status == 2){
                    $('#status').html("Status: Goedgekeurd").css('color', 'green');
                }else{
                    $('#status').html("Status: Afgekeurd").css('color', 'red');
                }
            }
        }

        $.ajax({
            url: "http://localhost:57280/api/stagevoorstellen/detail/" + <?php echo $_POST['id_opdracht']; ?>, //TODO
            type: "Get",
            dataType: "json",
            async: false,
            success: function (data) {
                //Contactpersoon
                $('#naamContactpersoon').html(data.Stageopdracht.Contactpersoon.Achternaam + " " + data.Stageopdracht.Contactpersoon.Voornaam);
                $('#emailContactpersoon').html(data.Stageopdracht.Contactpersoon.Email);
                $('#telefoonnummerContactpersoon').html(data.Stageopdracht.Contactpersoon.Telefoonnummer);

                //Bedrijspromotor
                $('#naamBedrijfspromotor').html(data.Stageopdracht.Bedrijfspromotor.Achternaam + " " + data.Stageopdracht.Bedrijfspromotor.Voornaam);
                $('#emailBedrijfspromotor').html(data.Stageopdracht.Bedrijfspromotor.Email);
                $('#telefoonnummerBedrijfspromotor').html(data.Stageopdracht.Bedrijfspromotor.Telefoonnummer);

                //Bedrijf
                $('#bedrijfsnaam').html(data.Opdrachtgever.Bedrijfsnaam);
                $('#adres').html(data.Opdrachtgever.Adres + " " + data.Opdrachtgever.Huisnummer);
                $('#gemeente').html(data.Opdrachtgever.Postcode + " " + data.Opdrachtgever.Gemeente);
                $('#telefoonnummer').html(data.Opdrachtgever.Telefoonnummer);

                //Technische informatie
                $('#aantalGewensteStagiairs').html(data.Stageopdracht.AantalGewensteStagiairs);
                $('#omgeving').html(data.Stageopdracht.Omgeving);
                $('#afstudeerrichting').html(getAfstudeerRichting(data.Stageopdracht.VoorkeurAfstudeerrichting));

                //Stageopdracht
                $('#omschrijving').html(data.Stageopdracht.Omschrijving);
                $('#verwachtingen').html(data.Stageopdracht.Verwachtingen);
                $('#randvoorwaarden').html(data.Stageopdracht.Randvoorwaarden);
                stagevoorstel = data;
                checkReview();

            },
            error: function (data, jqXHR, textStatus, errorThrown) {
                alert("Error: Status: " + textStatus + " Message: " + errorThrown + data);
            }
        });


        $('#goedkeurenButton').click(function () {
            stagevoorstel.Stageopdracht.Status = 2;
            stagevoorstel.Review = {Feedback : $('#feedback').val(), ReviewerId : sessionStorage.getItem("userId")};
            $.ajax({
                url: "http://localhost:57280/api/stagevoorstellen/" + <?php echo $_POST['id_opdracht']; ?>,
                type: "PUT",
                data: stagevoorstel,
                async: false,
                success: function (data) {

                },
                error: function (data, jqXHR, textStatus, errorThrown) {
                    alert("Error: Status: " + textStatus + " Message: " + errorThrown + data);
                }
            });
            checkReview();
        });

        $('#afkeurenButton').click(function () {
            stagevoorstel.Stageopdracht.Status = 3;
            stagevoorstel.Review = {Feedback : $('#feedback').val(), ReviewerId : sessionStorage.getItem("userId")};
            $.ajax({
                url: "http://localhost:57280/api/stagevoorstellen/" + <?php echo $_POST['id_opdracht']; ?>,
                type: "PUT",
                data: stagevoorstel,
                async: false,
                success: function (data) {

                },
                error: function (data, jqXHR, textStatus, errorThrown) {
                    alert("Error: Status: " + textStatus + " Message: " + errorThrown + data);
                }
            });
            checkReview();
        });
    });
</script>
</body>
</html>