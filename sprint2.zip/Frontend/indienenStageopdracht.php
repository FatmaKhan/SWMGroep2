<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Voorstel stageopdracht</title>

    <meta name="description" content="Review Stageopdracht">
    <meta name="author" content="AON13">

    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/styleHome.css" rel="stylesheet">

    <!-- Favicon and touch icons -->
    <link rel="shortcut icon" href="assets/ico/favicon.png">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-6">
                    <div class="row">
                        <div class="col-md-5">
                        </div>
                        <div class="col-md-7">

                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="row">
                        <div class="col-md-9">
                        </div>
                        <div class="col-md-3">
                            <a id="afmelden" href="verwerkAfmelden.php" class="btn btn-link">Afmelden<img
                                        id="afmeldenPng"
                                        alt="afmelden"
                                        src="assets/img/afmelden.png"/></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <img id="logoPxl" alt="Logo pxl" src="assets/img/pxllogowitterand.png">
                    <a href="bedrijfHomeScreen.php" class="btn btn-block home-btn">Home</a>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="container">
            <h2>
                Voorstel stageopdracht
            </h2>
            <div>
            <span style="text-align: center">
                <p>Via onderstaand formulier kunnen stageopdrachten voor PXL-IT worden ingegeven. Er staat geen limiet op het aantal opdrachten dat ingestuurd kan worden per bedrijf, maar we beperken het aantal stagiairs per bedrijf tot 2. </p>
                <p>Hopend op uw begrip.</p>
                <p>Stageperiodes: <br>
                - 19 september 2016 tot en met 16 december 2016 (semester 1)<br>
                - 3 oktober 2016 tot en met 13 januari 2017 (semester 1)<br>
                - 20 februari 2017 tot en met 2 juni 2017 (semester 2)<br></p>
            </span>
            </div>
            <span style="color: red">Vereist *</span>
            <form id="stagevoorstelForm">
                <div id="stageopdracht">
                    <h3>Stageopdracht</h3>
                    <br>
                    <label>Voorkeur afstudeerrichting *</label>
                    <div class="checkbox">
                        <label><input type="checkbox" name="VoorkeurAfstudeerrichting" id="voorkeurAfstudeerrichting"
                                      value=0 checked>Applicatie-ontwikkeling</label>
                    </div>
                    <div class="checkbox">
                        <label><input type="checkbox" name="VoorkeurAfstudeerrichting" value=1 class="btn btn-default">Systemen
                            en Netwerkbeheer</label>
                    </div>
                    <div class="checkbox">
                        <label><input type="checkbox" name="VoorkeurAfstudeerrichting" value=2 class="btn btn-default">Software
                            Management</label>
                    </div>
                    <br>
                    <div class="form-group">
                        <label for="omschrijving">Omschrijving van de opdracht *</label>
                        <textarea name="Omschrijving" id="omschrijving" class="form-control" rows="7" cols="60"
                                  required>Student maakt een applicatie voor een supermarkt</textarea>
                    </div>
                    <label>Omgeving *</label>
                    <div class="checkbox">
                        <label><input type="checkbox" name="Omgeving" value="Programmeren: Java" checked>Programmeren:
                            Java</label>
                    </div>
                    <div class="checkbox">
                        <label><input type="checkbox" name="Omgeving" value="Programmeren: .Net">Programmeren:
                            .Net</label>
                    </div>
                    <div class="checkbox">
                        <label><input type="checkbox" name="Omgeving" value="Web: CSS, Javascript, PHP, Angular, ...">Web:
                            CSS, Javascript, PHP, Angular, ...</label>
                    </div>
                    <div class="checkbox">
                        <label><input type="checkbox" name="Omgeving" value="Mobile: Android, iOS, Windows, ...">Mobile:
                            Android, iOS, Windows, ...</label>
                    </div>
                    <div class="checkbox">
                        <label><input type="checkbox" name="Omgeving" value="Systemen&Netwerken:  Linux, Windows, ...">Systemen&Netwerken:
                            Linux, Windows, ...</label>
                    </div>
                    <div class="checkbox">
                        <label><input type="checkbox" name="Omgeving"
                                      value="Software testing, ITIL, Projectmanagement, CRM, Information Management">Software
                            testing, ITIL, Projectmanagement, CRM, Information Management</label>
                    </div>
                    <br>
                    <div class="form-group">
                        <label for="randvoorwaarden">Randvoorwaarden</label>
                        <textarea name="Randvoorwaarden" id="randvoorwaarden" class="form-control" rows="7" cols="60">Student moet zich kunnen verplaatsen naar Brussel</textarea>
                    </div>
                    <div class="form-group">
                        <label for="onderzoeksthema">Onderzoeksthema</label>
                        <textarea name="Onderzoeksthema" id="onderzoeksthema" class="form-control" rows="7" cols="60">Onderzoeksthema,...</textarea>
                    </div>
                    <br>
                    <h3>Overige</h3>
                    <div class="row">
                        <div class="col-md-4">
                            <label>Inleidende activiteiten / verwachtingen</label>
                            <div class="checkbox">
                                <label><input type="checkbox" name="InleidendeActiviteit" value=0 checked>CV</label>
                            </div>
                            <div class="checkbox">
                                <label><input type="checkbox" name="InleidendeActiviteit"
                                              value=1>Sollicitatiegesprek</label>
                            </div>
                            <div class="checkbox">
                                <label><input type="checkbox" name="InleidendeActiviteit" value=2>Vergoeding /
                                    tegemoetkoming in verplaatsingskosten</label>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <label>Aantal gewenste stagiairs *</label>
                            <div class="radio">
                                <label><input type="radio" name="AantalGewensteStagiairs" value=0 checked>1
                                    student</label>
                            </div>
                            <div class="radio">
                                <label><input type="radio" name="AantalGewensteStagiairs" value=1>2 studenten</label>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <label>Stageperiode *</label><br>
                            <div class="checkbox">
                                <label><input type="checkbox" name="Stageperiode" value=0 checked>Semester 1
                                    (19/09/2016-16/12/2016 OF 03/10/2016-13/01/2017)</label>
                            </div>
                            <div class="checkbox">
                                <label><input type="checkbox" name="Stageperiode" value=1>Semester 2
                                    (20/02/2017-02/06/2017)</label>
                            </div>
                        </div>
                    </div>
                    <br>
                    <h3>Locatie</h3>
                    <div class="form-group">
                        <label for="locatie">Locatie van de stage (indien elders dan het adres van het
                            stagebedrijf)</label>
                        <textarea name="Locatie" id="locatie" class="form-control" rows="7" cols="60">Torenlaan 500 Brussel</textarea>
                    </div>
                    <br>
                    <div class="form-group">
                        <label for="aantalWerknemers">Aantal Medewerkers (op het bedrijf) *</label>
                        <input type="number" name="AantalWerknemers" id="aantalWerknemers" class="form-control"
                               value="200" required>
                    </div>
                    <div class="form-group">
                        <label for="aantalITWerknemers">Aantal IT-medewerkers (op het bedrijf) *</label>
                        <input type="number" name="AantalITWerknemers" id="aantalITWerknemers" class="form-control"
                               value="100" required>
                    </div>
                    <div class="form-group">
                        <label for="aantalITBegeleiders">Aantal IT-medewerkers (op het bedrijf) *</label>
                        <input type="number" name="AantalITBegeleiders" id="aantalITBegeleiders" class="form-control"
                               value="10" required>
                    </div>
                </div>
                <br>
                <div id="contactpersoon">
                    <h3>
                        Contactpersoon
                    </h3>
                    <p>Deze persoon zal de stagedocumenten ondertekenen</p><br>
                    <div class="form-group">
                        <label for="title">Titel *</label>
                        <input type="text" name="Title" id="title" class="form-control" value="Mvr" required>
                    </div>
                    <div class="form-group">
                        <label for="achternaam">Naam *</label>
                        <input type="text" name="Achernaam" id="achternaam" class="form-control" value="Janssen"
                               required>
                    </div>
                    <div class="form-group">
                        <label for="voornaam">Voornaam *</label>
                        <input type="text" name="Voornaam" id="voornaam" class="form-control" value="Eva" required>
                    </div>
                    <div class="form-group">
                        <label for="telefoonnummer">Telefoonnummer *</label>
                        <input type="text" name="Telefoonnummer" id="telefoonnummer" class="form-control" required
                               pattern=".*\+?\(?\d{2,4}\)?[\d\s-]{3,}.*" value="011787878">
                    </div>
                    <div class="form-group">
                        <label for="email">E-mail adres contactpersoon *</label>
                        <input type="text" name="Email" id="email" class="form-control" required
                               pattern=".*[a-zA-Z0-9_\.\+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-\.]+.*"
                               value="eva.janssen@hotmail.com">
                    </div>
                </div>
                <br>
                <div id="bedrijfspromotor">
                    <h3>Bedrijfspromotor (in het bedrijf)</h3>
                    <p>Deze persoon zal de student technisch begeleiden tijdens de stageperiode en zal tevens aanwezig
                        zijn tijdens het juryexamen van de student</p><br>
                    <div class="form-group">
                        <label for="title">Titel *</label>
                        <input type="text" name="Title" id="title" class="form-control" value="Mr" required>
                    </div>
                    <div class="form-group">
                        <label for="achternaam">Naam *</label>
                        <input type="text" name="Achternaam" id="achternaam" class="form-control" value="Janssen"
                               required>
                    </div>
                    <div class="form-group">
                        <label for="voornaam">Voornaam *</label><br>
                        <input type="text" name="Voornaam" id="voornaam" class="form-control" value="Jos" required>
                    </div>
                    <div class="form-group">
                        <label for="telefoonnummer">Telefoonnummer *</label>
                        <input type="text" name="Telefoonnummer" id="telefoonnummer" class="form-control" required
                               pattern=".*\+?\(?\d{2,4}\)?[\d\s-]{3,}.*" value="011565656">
                    </div>
                    <div class="form-group">
                        <label for="email">E-mail adres contactpersoon *</label>
                        <input type="text" name="Email" id="email" class="form-control" required
                               pattern=".*[a-zA-Z0-9_\.\+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-\.]+.*"
                               value="jos.janssen@hotmail.com">
                    </div>
                </div>
                <br>
                <button type="submit" value="Verzenden" class="verzenden" id="sendButton">Verzenden</button>
                <br>
                <br>
            </form>
        </div>
    </div>
</div>

<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/afmelden.js"></script>
<script src="assets/js/sessionTimeout.js"></script>
<script>
    $(document).ready(function () {
        $("#stagevoorstelForm").submit(function (e) {
            e.preventDefault();
            var contactpersoon = JSON.stringify(objectifyForm($("#contactpersoon :input").serializeArray()));
            var bedrijfspromotor = JSON.stringify(objectifyForm($("#bedrijfspromotor :input").serializeArray()));
            bedrijfspromotor = bedrijfspromotor.slice(0, -1) + ', "BedrijfInDienstId" : ' + 1 + '}';
            var stageopdracht = JSON.stringify(objectifyForm($("#stageopdracht :input").serializeArray()));
            stageopdracht = stageopdracht.slice(0, -1) + ', "Bedrijfspromotor" : ' + bedrijfspromotor + ', "Contactpersoon" : ' + contactpersoon + ", Status : " + 0 + ', OpdrachtgeverId : ' + sessionStorage.getItem("userId") + '}';
            var stagevoorstel = '{"Timestamp" : ' + "\"" + new Date().toISOString().slice(0, 19).replace('T', ' ') + "\"" +
                ', "Verstuurd" : ' + true + ', "Stageopdracht" : ' + stageopdracht + ', OpdrachtgeverId : ' +
                sessionStorage.getItem("userId") + ', StagecoördinatorBehandelingLectorId : ' + 1 + '}';
            postData(stagevoorstel);
        });

        function objectifyForm(formArray) {

            var returnArray = {};
            for (var i = 0; i < formArray.length; i++) {
                returnArray[formArray[i]['name']] = formArray[i]['value'];
            }
            return returnArray;
        }

        function postData(data) {
            $.ajax({
                url: 'http://localhost:57280/api/stagevoorstellen',
                type: 'POST',
                contentType: 'application/json; charset=utf-8',
                dataType: 'json',
                data: data,
                success: function () {
                    window.location.href = "bedrijfHomeScreen.php";
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    alert("Error: Status: " + textStatus + " Message: " + errorThrown);
                }
            });
        }
    });
</script>
</body>
</html>